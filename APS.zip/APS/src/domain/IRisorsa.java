package domain;

public interface IRisorsa {

	public abstract Object clone();
}

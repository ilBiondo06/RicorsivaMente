package domain;

public class Utente {
	
	private String nome;
	private String cognome;
	private String password;
	private String email;
	private boolean consenso = false;
	private String username;
	
	public Utente() {
		
	}
	
	public void setPassword(String psw) {
		
	}

	public void setNome(String n) {
		
	}

	public void setCognome(String c) {

	}

	public void setEmail(String e) {

	}

	public void setConsenso(boolean consenso) {

	}

	public void setUsername(String us) {
		
	}
	
	
}
